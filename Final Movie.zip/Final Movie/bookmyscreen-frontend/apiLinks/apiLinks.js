export const userUrl='http://localhost:8000/' 
export const ownerUrl = 'http://localhost:8000/owner/'
export const adminUrl ='http://localhost:8000/admin/'



// export const userUrl='https://bookmyscreen.onrender.com/' 
// export const ownerUrl = 'https://bookmyscreen.onrender.com/owner/'
// export const adminUrl ='https://bookmyscreen.onrender.com/admin/' 



// export const userUrl='https://echo-cart.shop./' 
// export const ownerUrl = 'https://echo-cart.shop./owner/'
// export const adminUrl ='https://echo-cart.shop./admin/'


export const movieUrl ='https://api.themoviedb.org/3'




