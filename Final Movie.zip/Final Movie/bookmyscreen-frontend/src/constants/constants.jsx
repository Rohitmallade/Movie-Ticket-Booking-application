export const imageUrl = "https://image.tmdb.org/t/p/w500"
export const API_KEY = "a16115323f4b6863e6772960d6d13c22"