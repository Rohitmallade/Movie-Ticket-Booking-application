import React from 'react'

 function OwnerProfile() {
  return (
    <div>
      <h2>here</h2>
    </div>
  )
}

export default OwnerProfile
