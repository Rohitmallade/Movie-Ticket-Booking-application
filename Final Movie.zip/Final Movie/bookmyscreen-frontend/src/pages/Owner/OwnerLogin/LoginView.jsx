import React from 'react';


import OwnerLogin from '../../../components/OwnerLogin/OwnerLogin';

const LoginView = () => (
  <main >
   
      <OwnerLogin />
   
  </main>
);

export default LoginView;
