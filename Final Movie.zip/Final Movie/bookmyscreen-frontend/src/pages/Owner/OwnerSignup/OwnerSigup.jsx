import React from 'react'
import SignUp from '../../../components/OwnerSignup/SignUp'

 function OwnerSignup() {
  return (
    <div>
      <SignUp/>
    </div>
  )
}

export default OwnerSignup
