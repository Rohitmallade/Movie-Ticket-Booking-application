import mongoose from "mongoose";

const connection = ()=>{
    mongoose.connect(process.env.MONGO_ID)
    console.log('connected');
}

export default connection   